
export const passage2 = {
title:"Can the planet’s coral reefs be saved?",
content:`<h2>Coral Reefs</h2><p>(Insert full Passage 2 text here)</p>`,
questions:[
{id:14,answer:"v"},
{id:15,answer:"ii"},
{id:16,answer:"iv"},
{id:17,answer:"vii"},
{id:18,answer:"iii"},
{id:19,answer:"vi"},
{id:24,answer:"tentacles"},
{id:25,answer:"protection"},
{id:26,answer:"colour"}
]
}
