
export const passage1 = {

title:"Frozen Food",

content:`
<h2>Frozen Food</h2>
<p>
At some point in history, humans discovered that ice preserved food...
(This is where the full Passage 1 text you provided should be placed.)
</p>
`,

questions:[
{id:1,question:"People conserved the nutritional value of ______",answer:"potatoes"},
{id:2,question:"______ was kept cool by ice during transportation",answer:"butter"},
{id:3,question:"Two kinds of ______ were the first frozen food shipped",answer:"meat"},
{id:4,question:"quick-freezing methods so that ______ did not spoil the food",answer:"crystals"},
{id:5,question:"packaging products with ______ so the product was visible",answer:"cellophane"},
{id:6,question:"Frozen food became popular because of shortage of ______",answer:"tin"},
{id:7,question:"A large number of homes now had a ______",answer:"refrigerator"}
]

}
