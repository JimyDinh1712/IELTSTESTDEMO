
export const passage3 = {
title:"Robots and us",
content:`<h2>Robots and us</h2><p>(Insert full Passage 3 text here)</p>`,
questions:[
{id:27,answer:"A"},
{id:28,answer:"C"},
{id:29,answer:"B"},
{id:30,answer:"A"},
{id:31,answer:"B"},
{id:32,answer:"A"},
{id:33,answer:"C"}
]
}
