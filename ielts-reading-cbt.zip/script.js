
import { passage1 } from './data/passage1.js'

let questions = passage1.questions

document.getElementById("passage").innerHTML = passage1.content

let qHTML = ""

questions.forEach(q=>{
qHTML += `<div class="question">
<p><b>${q.id}</b>. ${q.question || ""}</p>
<input type="text" onchange="saveAnswer(${q.id},this.value)">
</div>`
})

document.getElementById("questions").innerHTML = qHTML

let navHTML = ""

for(let i=1;i<=40;i++){
navHTML += `<button onclick="go(${i})">${i}</button>`
}

document.getElementById("nav").innerHTML = navHTML

window.saveAnswer = function(q,val){
localStorage.setItem("q"+q,val)
}

window.go = function(n){
alert("Jump to question "+n)
}

document.getElementById("submit").onclick = function(){

let score = 0

questions.forEach(q=>{

let user = localStorage.getItem("q"+q.id)

if(user && user.toLowerCase() == q.answer.toLowerCase()){
score++
}

})

alert("Score: "+score+"/40")

}

let time = 60*60

setInterval(()=>{

let min = Math.floor(time/60)
let sec = time%60

document.getElementById("timer").innerText =
min + ":" + (sec<10?"0":"")+sec

time--

},1000)
